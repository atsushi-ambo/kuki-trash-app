const skillModule = require('./index');
const handler = skillModule.handler;

// Lambda コンテキストを模擬
const mockContext = {
    callbackWaitsForEmptyEventLoop: false,
    functionName: 'test-function',
    functionVersion: '$LATEST',
    invokedFunctionArn: 'arn:aws:lambda:ap-northeast-1:123456789012:function:test-function',
    memoryLimitInMB: '512',
    awsRequestId: 'test-request-id',
    logGroupName: '/aws/lambda/test-function',
    logStreamName: '2025/01/01/[$LATEST]test-stream',
    getRemainingTimeInMillis: () => 30000,
    done: (error, result) => {
        if (error) {
            console.log('❌ Error:', error);
        } else {
            console.log('✅ Success:', JSON.stringify(result, null, 2));
        }
    },
    fail: (error) => console.log('❌ Fail:', error),
    succeed: (result) => console.log('✅ Succeed:', JSON.stringify(result, null, 2))
};

// デバッグ用のテストケース
async function runDebugTests() {
    console.log('🐛 === Alexa Skill Debug Tests ===');

    // Test 1: Launch Request
    console.log('\n📍 Test 1: Launch Request');
    const launchRequest = {
        "version": "1.0",
        "session": {
            "new": true,
            "sessionId": "amzn1.echo-api.session.debug",
            "application": { "applicationId": "amzn1.ask.skill.debug" },
            "attributes": {},
            "user": { "userId": "amzn1.ask.account.debug" }
        },
        "context": {
            "System": {
                "application": { "applicationId": "amzn1.ask.skill.debug" },
                "user": { "userId": "amzn1.ask.account.debug" },
                "device": { "deviceId": "debug", "supportedInterfaces": {} }
            }
        },
        "request": {
            "type": "LaunchRequest",
            "requestId": "amzn1.echo-api.request.debug1",
            "timestamp": new Date().toISOString(),
            "locale": "ja-JP"
        }
    };

    try {
        const response1 = await new Promise((resolve, reject) => {
            const context = {
                ...mockContext,
                done: (error, result) => {
                    if (error) reject(error);
                    else resolve(result);
                }
            };
            handler(launchRequest, context, (error, result) => {
                if (error) reject(error);
                else resolve(result);
            });
        });
        console.log('✅ Launch Response Speech:', response1.response.outputSpeech.ssml);
    } catch (error) {
        console.log('❌ Launch Error:', error.message);
    }

    // Test 2: ペットボトル検索
    console.log('\n📍 Test 2: ペットボトル検索');
    const petBottleRequest = {
        ...launchRequest,
        "session": {
            ...launchRequest.session,
            "new": false,
            "attributes": {}
        },
        "request": {
            "type": "IntentRequest",
            "requestId": "amzn1.echo-api.request.debug2",
            "timestamp": new Date().toISOString(),
            "locale": "ja-JP",
            "intent": {
                "name": "GarbageSearchIntent",
                "slots": {
                    "GarbageItem": {
                        "name": "GarbageItem",
                        "value": "ペットボトル"
                    }
                }
            }
        }
    };

    try {
        const response2 = await new Promise((resolve, reject) => {
            const context = {
                ...mockContext,
                done: (error, result) => {
                    if (error) reject(error);
                    else resolve(result);
                }
            };
            handler(petBottleRequest, context, (error, result) => {
                if (error) reject(error);
                else resolve(result);
            });
        });
        console.log('✅ Pet Bottle Response Speech:', response2.response.outputSpeech.ssml);
    } catch (error) {
        console.log('❌ Pet Bottle Error:', error.message);
    }

    // Test 3: 今日のゴミ検索（地域設定なし）
    console.log('\n📍 Test 3: 今日のゴミ検索（地域設定なし）');
    const todayGarbageRequest = {
        ...launchRequest,
        "session": {
            ...launchRequest.session,
            "new": false,
            "attributes": {} // 地域設定なし
        },
        "request": {
            "type": "IntentRequest",
            "requestId": "amzn1.echo-api.request.debug3",
            "timestamp": new Date().toISOString(),
            "locale": "ja-JP",
            "intent": {
                "name": "GarbageSearchIntent",
                "slots": {
                    "GarbageItem": {
                        "name": "GarbageItem",
                        "value": "今日のゴミは何"
                    }
                }
            }
        }
    };

    try {
        const response3 = await new Promise((resolve, reject) => {
            const context = {
                ...mockContext,
                done: (error, result) => {
                    if (error) reject(error);
                    else resolve(result);
                }
            };
            handler(todayGarbageRequest, context, (error, result) => {
                if (error) reject(error);
                else resolve(result);
            });
        });
        console.log('✅ Today Garbage Response Speech:', response3.response.outputSpeech.ssml);
    } catch (error) {
        console.log('❌ Today Garbage Error:', error.message);
    }

    // Test 4: 地域設定
    console.log('\n📍 Test 4: 地域設定');
    const regionSettingRequest = {
        ...launchRequest,
        "session": {
            ...launchRequest.session,
            "new": false,
            "attributes": {}
        },
        "request": {
            "type": "IntentRequest",
            "requestId": "amzn1.echo-api.request.debug4",
            "timestamp": new Date().toISOString(),
            "locale": "ja-JP",
            "intent": {
                "name": "RegionSettingIntent",
                "slots": {
                    "Region": {
                        "name": "Region",
                        "value": "Aブロック"
                    }
                }
            }
        }
    };

    try {
        const response4 = await new Promise((resolve, reject) => {
            const context = {
                ...mockContext,
                done: (error, result) => {
                    if (error) reject(error);
                    else resolve(result);
                }
            };
            handler(regionSettingRequest, context, (error, result) => {
                if (error) reject(error);
                else resolve(result);
            });
        });
        console.log('✅ Region Setting Response Speech:', response4.response.outputSpeech.ssml);
        console.log('Session Attributes:', response4.sessionAttributes);
    } catch (error) {
        console.log('❌ Region Setting Error:', error.message);
    }

    console.log('\n🎯 === Debug Tests Completed ===');
}

// Test execution
if (require.main === module) {
    runDebugTests().catch(console.error);
}

module.exports = { runDebugTests };

// Test execution
if (require.main === module) {
    runDebugTests().catch(console.error);
}

module.exports = { runDebugTests };
